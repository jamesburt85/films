<?php

namespace DeliciousBrains\WPMDBTP;

class ThemePluginFilesLocal {
    //Silence is golden.
}
