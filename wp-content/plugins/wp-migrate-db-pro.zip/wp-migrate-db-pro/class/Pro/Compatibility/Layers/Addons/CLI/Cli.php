<?php

namespace DeliciousBrains\WPMDBCli;

class Cli{
    //Silence is golden.
}
